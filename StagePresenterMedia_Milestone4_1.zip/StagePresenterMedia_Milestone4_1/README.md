# StagePresenter Media — Milestone 4.1

StagePresenter Media is a Windows live-presentation controller focused only on the presentation functions requested for this project: **run sheets, images, audio, video, and projector output**.

## Current operator workflow

1. Connect a projector/second display and set Windows to **Extend**.
2. Add images, video, and audio to the run sheet (multi-select and drag/drop supported).
3. Arrange items in presentation order.
4. Select the projector display and click **Open Projector**. It opens black.
5. Select an item and click **TAKE LIVE** (or press Enter).
6. Control video/audio with Play/Pause, Stop, Seek, Volume, Mute, Loop, and Auto Advance.
7. Press **B** to black/unblack the projector without stopping video/audio playback.
8. Save the run sheet or create a **Portable Run Sheet** that copies all media into one transferable folder.

## Milestone 4 additions

- LibVLCSharp playback engine instead of WPF/Windows-codec-dependent playback.
- MP4, MOV, MKV, WebM, AVI, WMV, MPEG, TS/M2TS/MTS, FLV, 3GP/3G2 video selection.
- MP3, WAV, M4A, AAC, FLAC, OGG, Opus, WMA, MP2 audio selection.
- Projector BLACK is now a visibility state; video/audio keeps running behind it.
- Portable run-sheet packaging with relative media paths.
- Relink one missing media file or scan a folder to relink many by filename.
- Missing-media checker.
- Autosave/recovery every 10 seconds while a run sheet has unsaved changes.
- Unsaved-change prompts on New/Open/Exit.
- Remembers last projector and media/run-sheet folders.
- Projector windows do not activate or steal operator keyboard focus.
- Mixed-DPI projector placement retained from Milestone 3.
- Self-contained Windows x64 publishing script.
- Inno Setup installer definition.
- GitHub Actions Windows release workflow.

## Build it on Windows

The fastest local route is to double-click **BUILD_RELEASE.cmd**. The script checks for .NET 10, can install it through winget when missing, publishes a self-contained x64 release, creates a portable ZIP, and builds an installer when Inno Setup is available.

Outputs are placed in `artifacts/`:

- `StagePresenterMedia-win-x64-0.4.1.zip`
- `StagePresenterMedia-Setup-0.4.1.exe` (when Inno Setup is available)

See `docs/BUILD_AND_RELEASE.md` for alternatives.

## Milestone 4.1 build fix

- Windows runtime packs are now restored explicitly with `dotnet restore -r win-x64` before `publish --no-restore`.
- Native command exit codes are checked, so packaging stops immediately if restore/publish/install fails.
- ZIP creation only starts after `StagePresenter.exe` is verified in the publish folder.
- GitHub Actions uses the same RID-aware restore path.

## Important verification status

This source tree has been statically checked for XML/XAML validity, handler wiring, and C# structural balance in the current environment. The current environment does **not** contain the Windows .NET SDK, so it cannot execute the WPF Windows build or physically test HDMI/projector output. Run `BUILD_RELEASE.cmd` on Windows or use the included GitHub Actions workflow for the actual Windows compile.
