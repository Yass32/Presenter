$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Project = Join-Path $Root "src\StagePresenter.App\StagePresenter.App.csproj"
$Artifacts = Join-Path $Root "artifacts"
$Publish = Join-Path $Artifacts "StagePresenter-win-x64"
$Rid = "win-x64"
$Version = "0.4.1"

function Assert-NativeSuccess {
    param([Parameter(Mandatory=$true)][string]$Step)
    if ($LASTEXITCODE -ne 0) {
        throw "$Step failed with exit code $LASTEXITCODE."
    }
}

function Test-DotNet10 {
    $dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
    if (-not $dotnet) { return $false }
    try {
        $sdks = & dotnet --list-sdks 2>$null
        return [bool]($sdks | Where-Object { $_ -match '^10\.' })
    } catch { return $false }
}

function Ensure-DotNet10 {
    if (Test-DotNet10) { return }
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if (-not $winget) {
        throw ".NET 10 SDK was not found. Install the .NET 10 SDK, then run BUILD_RELEASE.cmd again."
    }
    Write-Host ".NET 10 SDK not found. Installing it with winget..."
    & winget install --id Microsoft.DotNet.SDK.10 --exact --accept-source-agreements --accept-package-agreements --silent
    Assert-NativeSuccess "Installing .NET 10 SDK"
    $env:PATH = "$env:ProgramFiles\dotnet;$env:PATH"
    if (-not (Test-DotNet10)) {
        throw ".NET 10 installation completed but the SDK is not available in this shell. Reopen the terminal and run BUILD_RELEASE.cmd again."
    }
}

function Find-InnoSetup {
    $paths = @(
        "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
        "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
    )
    foreach ($p in $paths) { if (Test-Path $p) { return $p } }
    return $null
}

Ensure-DotNet10
New-Item -ItemType Directory -Force -Path $Artifacts | Out-Null
if (Test-Path $Publish) { Remove-Item $Publish -Recurse -Force }

Write-Host "Restoring packages and Windows x64 runtime packs..."
& dotnet restore $Project -r $Rid
Assert-NativeSuccess "dotnet restore ($Rid)"

Write-Host "Publishing self-contained Windows x64 release..."
& dotnet publish $Project -c Release -r $Rid --self-contained true --no-restore -o $Publish -p:DebugType=None -p:DebugSymbols=false
Assert-NativeSuccess "dotnet publish ($Rid)"

$PublishedExe = Join-Path $Publish "StagePresenter.exe"
if (-not (Test-Path $PublishedExe)) {
    throw "Publish command completed but StagePresenter.exe was not found at $PublishedExe. Packaging has been stopped."
}

$Zip = Join-Path $Artifacts "StagePresenterMedia-win-x64-$Version.zip"
if (Test-Path $Zip) { Remove-Item $Zip -Force }
Write-Host "Creating portable release ZIP..."
Compress-Archive -Path (Join-Path $Publish "*") -DestinationPath $Zip -CompressionLevel Optimal
if (-not (Test-Path $Zip)) {
    throw "Portable ZIP was not created: $Zip"
}
Write-Host "Portable release created: $Zip"

$Iscc = Find-InnoSetup
if (-not $Iscc -and (Get-Command winget -ErrorAction SilentlyContinue)) {
    Write-Host "Inno Setup not found. Installing it to build the Windows installer..."
    & winget install --id JRSoftware.InnoSetup --exact --accept-source-agreements --accept-package-agreements --silent
    Assert-NativeSuccess "Installing Inno Setup"
    $Iscc = Find-InnoSetup
}

if ($Iscc) {
    Write-Host "Building installer..."
    & $Iscc (Join-Path $Root "installer\StagePresenter.iss")
    Assert-NativeSuccess "Inno Setup installer build"
    Write-Host "Installer build complete."
} else {
    Write-Warning "Inno Setup is unavailable. The portable release ZIP was still created successfully."
}

Write-Host ""
Write-Host "Release build finished successfully." -ForegroundColor Green
Write-Host "Artifacts: $Artifacts"
