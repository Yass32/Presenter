# Third-party components

StagePresenter Media Milestone 4 uses VideoLAN's LibVLCSharp WPF bindings and the VideoLAN LibVLC Windows runtime through NuGet.

- LibVLCSharp.WPF: version 3.10.1, maintained by VideoLAN, LGPL-2.1-or-later.
- VideoLAN.LibVLC.Windows: version 3.0.24, maintained by VideoLAN. Review the package's included license notices when distributing binaries.

The application source written for this project does not incorporate Presenter Software source code or branded assets.
