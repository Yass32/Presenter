# Milestone 4 — Release-oriented media presenter

Scope is deliberately restricted to live presentation operation: run sheets, images, audio, video, and projector output. Lyrics, text composition, shapes, Scripture, PowerPoint authoring, and display-scheme editors are outside scope.

## Implemented

- LibVLCSharp + bundled Windows LibVLC runtime through NuGet.
- Dedicated projector output window.
- Run-sheet reorder/remove/relink.
- Image Fit/Fill and timed auto-advance.
- Video/audio play, pause, stop, seek, volume, mute, loop, auto-advance.
- Black/unblack without stopping live AV playback.
- Portable run-sheet packaging.
- Relative paths for media stored beside the run sheet.
- Missing-media repair tools.
- Autosave and recovery.
- Save/Save As/new/open protection.
- Display preference persistence.
- Build/publish/installer automation.

## Still requires physical Windows QA

- Projector hot-plug while output is open.
- HDMI audio routing on different GPU/audio-driver combinations.
- 4K projector scaling and mixed-DPI edge cases.
- Very high bitrate 4K/H.265 playback under target hardware.
- Installer SmartScreen behavior (unsigned installer).
- Actual compile verification on Windows.
