# Projector setup

1. Connect the projector/TV through HDMI/DisplayPort/USB-C.
2. In Windows Display Settings choose **Extend these displays** — do not use Duplicate.
3. Start StagePresenter Media.
4. Use **Refresh Displays** if the projector was connected after the app opened.
5. Select the non-primary projector from the display list.
6. Click **Open Projector**. The projector opens black so no desktop content is exposed.
7. Select a run-sheet item and click **TAKE LIVE**.
8. Press `B` at any time to hide/reveal the output. Video/audio playback continues while black.

For audio over HDMI, select the projector/HDMI device as the desired Windows audio output before starting the event if that is where sound should play.
