# Presentation functionality matrix

| Capability | Milestone 4 |
|---|---|
| Run sheet | Implemented |
| Add multiple media files | Implemented |
| Drag/drop media files | Implemented |
| Drag/drop media folder (top level) | Implemented |
| Reorder/remove | Implemented |
| Image preview | Implemented |
| Video preview frame | Implemented via LibVLC |
| Image live output | Implemented |
| Video live output | Implemented via LibVLC |
| Audio live playback | Implemented via LibVLC; projector remains black |
| Projector/second display | Implemented |
| Open projector black | Implemented |
| Black/unblack without stopping AV | Implemented |
| Play/Pause/Stop | Implemented |
| Seek | Implemented |
| Volume/mute | Implemented |
| Loop | Implemented |
| Auto-advance after AV ends | Implemented |
| Timed image auto-advance | Implemented |
| Image Fit/Fill | Implemented |
| Save/Open run sheet | Implemented |
| Relative paths when media is beside run sheet | Implemented |
| Portable package | Implemented |
| Relink selected media | Implemented |
| Bulk relink missing media by filename | Implemented |
| Missing-media validation | Implemented |
| Autosave/recovery | Implemented |
| Remember projector | Implemented |
| Windows self-contained publish script | Implemented |
| Installer definition | Implemented |
| Windows CI build workflow | Implemented |
| Physical projector QA | Pending Windows/hardware test |
| Text/lyrics/shapes | Out of scope by request |
