# Keyboard shortcuts

- `Enter` — take selected run-sheet item live
- `Space` — toggle Play/Pause for live audio/video
- `B` — black/unblack projector
- `Page Down` — next live run-sheet item
- `Page Up` — previous live run-sheet item
- `Delete` — remove selected run-sheet item
- `Ctrl+S` — save
- `Ctrl+Shift+S` — save as
- `Ctrl+O` — open run sheet
- `Ctrl+N` — new run sheet
