# Milestone 4.1

Build-pipeline correction for Windows self-contained publishing.

## Fixed
- Explicit `win-x64` restore so .NET runtime packs are downloaded before `publish --no-restore`.
- PowerShell now detects non-zero exit codes from `dotnet`, `winget`, and Inno Setup.
- Packaging stops immediately when publish fails.
- ZIP packaging verifies `StagePresenter.exe` exists first.
- GitHub Actions release workflow updated to use RID-aware restore.
- Application and installer version bumped to 0.4.1.
