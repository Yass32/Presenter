# StagePresenter Media — Windows / Projector QA Checklist

Use this checklist on the actual presentation laptop before a live event.

## Build / launch
- Run `BUILD_RELEASE.cmd` and confirm the portable ZIP is created.
- Install with the generated Setup EXE or run `StagePresenter.exe` from the portable folder.
- Confirm the app launches without requiring a separate .NET installation.

## Display
- Connect the projector/TV by HDMI/DisplayPort/USB-C.
- Windows Display Settings: choose **Extend these displays**.
- In StagePresenter, refresh displays and select the projector, not the operator screen.
- Open Projector: output should start black and must not steal keyboard focus.
- Test projector at its native resolution and, if relevant, mixed Windows scaling (100%/125%/150%).

## Images
- Add JPG and PNG files.
- Test Fit and Fill.
- Test manual previous/next and timed Auto Advance.
- Press B while an image is live; projector should black/unblack correctly.

## Video
- Test at least one H.264 MP4 at the resolution used for the event.
- Test Play/Pause, Stop, seeking, volume, mute, loop, and Auto Advance.
- Press B during playback; sound/video timing should continue behind black and be at the expected position after unblack.
- Test a long video and the highest-bitrate file expected at the event.

## Audio
- Test MP3/WAV or the actual show audio files.
- Confirm the projector remains visually black during audio-only playback.
- Verify Windows audio is routed to the intended HDMI/interface/speakers.
- Test volume, mute, loop, seek, and Auto Advance.

## Run sheet / portability
- Save, close, reopen the run sheet.
- Move a media file and test Relink Selected.
- Test Relink Missing from Folder.
- Create a Portable Run Sheet, copy the whole portable folder elsewhere, and reopen its `.sprevent` file.

## Recovery
- Make an unsaved change, wait >10 seconds, force-close the app from Task Manager, then relaunch and confirm recovery is offered.

## Final live-event check
- Disable sleep/screensaver/automatic restart for the event window.
- Connect AC power.
- Open every show-critical media item once before doors open.
- Keep the portable run-sheet folder on a backup USB drive or second machine.
