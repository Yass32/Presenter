# Build and Release

## Option A — one-click local build

On Windows, double-click `BUILD_RELEASE.cmd`.

The script:
1. checks for the .NET 10 SDK;
2. uses winget to install it if needed;
3. restores LibVLCSharp/LibVLC packages **and the win-x64 .NET runtime packs**;
4. publishes a **self-contained win-x64** application folder;
5. creates a portable ZIP;
6. installs/uses Inno Setup when available and creates a Windows installer.

The release is intentionally not published as a single-file executable because LibVLC includes native libraries and plugin folders that should remain beside the application executable.

## Option B — Visual Studio

Open `StagePresenterMedia.sln`, restore NuGet packages, select Release/x64, then Build. For a transferable release use Publish with `win-x64` and self-contained deployment.

## Option C — GitHub Actions

Push this folder to a GitHub repository. Open **Actions > Build Windows Release > Run workflow**. The workflow uses a Windows runner and produces two downloadable artifacts:

- portable ZIP
- Windows installer EXE

No Windows SDK needs to be installed on your own computer for this route.

## Signing

The installer is unsigned. For distribution outside your own machines, add an Authenticode code-signing certificate to reduce Windows SmartScreen warnings.


## NETSDK1112 fix in 0.4.1

If Milestone 4 reported `NETSDK1112` for `Microsoft.NETCore.App.Runtime.win-x64` or `Microsoft.WindowsDesktop.App.Runtime.win-x64`, the release script had restored without an explicit runtime identifier and then published with `--no-restore`. Version 0.4.1 fixes this by running:

```powershell
dotnet restore <project> -r win-x64
dotnet publish <project> -c Release -r win-x64 --self-contained true --no-restore
```

The script now also checks native-process exit codes and stops before ZIP creation if publish fails.
