namespace StagePresenter.Models;

public sealed class RunSheetDocument
{
    public int FormatVersion { get; set; } = 4;
    public string Name { get; set; } = "Untitled Run Sheet";
    public DateTime ModifiedUtc { get; set; } = DateTime.UtcNow;
    public List<RunSheetItem> Items { get; set; } = new();

    public RunSheetDocument Clone() => new()
    {
        FormatVersion = FormatVersion,
        Name = Name,
        ModifiedUtc = ModifiedUtc,
        Items = Items.Select(x => x.Clone()).ToList()
    };
}
