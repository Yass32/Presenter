using System.Text.Json.Serialization;

namespace StagePresenter.Models;

public enum RunSheetItemType
{
    UnsupportedText = 0,
    Image = 1,
    Video = 2,
    Audio = 3,
    UnsupportedMessage = 4,
    UnsupportedScripture = 5,
    UnsupportedPowerPoint = 6
}

public enum ImageScaleMode
{
    Fit,
    Fill
}

public sealed class RunSheetItem
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public RunSheetItemType Type { get; set; }
    public string Title { get; set; } = "Untitled";
    public string? SourcePath { get; set; }
    public bool Loop { get; set; }
    public bool AutoAdvance { get; set; }
    public double Volume { get; set; } = 1.0;
    public double ImageDurationSeconds { get; set; } = 5.0;
    public ImageScaleMode ImageScale { get; set; } = ImageScaleMode.Fit;

    [JsonIgnore]
    public string TypeLabel => Type switch
    {
        RunSheetItemType.Image => "IMAGE",
        RunSheetItemType.Video => "VIDEO",
        RunSheetItemType.Audio => "AUDIO",
        _ => "UNSUPPORTED"
    };

    [JsonIgnore]
    public string FileName => string.IsNullOrWhiteSpace(SourcePath) ? string.Empty : Path.GetFileName(SourcePath);

    [JsonIgnore]
    public bool FileExists => !string.IsNullOrWhiteSpace(SourcePath) && File.Exists(SourcePath);

    public RunSheetItem Clone() => new()
    {
        Id = Id,
        Type = Type,
        Title = Title,
        SourcePath = SourcePath,
        Loop = Loop,
        AutoAdvance = AutoAdvance,
        Volume = Volume,
        ImageDurationSeconds = ImageDurationSeconds,
        ImageScale = ImageScale
    };
}
