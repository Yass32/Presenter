using LibVLCSharp.Shared;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using StagePresenter.Models;
using StagePresenter.Services;

namespace StagePresenter.Views;

public partial class OutputWindow : Window
{
    private readonly MediaPlayer _player;
    private bool _loop;
    private bool _muted;
    private bool _black;
    private double _volume = 1.0;

    public event EventHandler? PlaybackEnded;
    public event EventHandler? PlaybackOpened;
    public event EventHandler? PlaybackStateChanged;
    public event Action<string>? PlaybackFailed;

    public OutputWindow()
    {
        InitializeComponent();
        _player = new MediaPlayer(MediaRuntime.LibVlc);
        VideoSurface.MediaPlayer = _player;

        _player.Playing += (_, _) => Dispatcher.BeginInvoke(() =>
        {
            ApplyAudioState();
            PlaybackOpened?.Invoke(this, EventArgs.Empty);
            PlaybackStateChanged?.Invoke(this, EventArgs.Empty);
        });
        _player.Paused += (_, _) => Dispatcher.BeginInvoke(() => PlaybackStateChanged?.Invoke(this, EventArgs.Empty));
        _player.Stopped += (_, _) => Dispatcher.BeginInvoke(() => PlaybackStateChanged?.Invoke(this, EventArgs.Empty));
        _player.EndReached += (_, _) => Dispatcher.BeginInvoke(() =>
        {
            if (_loop)
            {
                try
                {
                    _player.Time = 0;
                    _player.Play();
                }
                catch { }
            }
            else
            {
                PlaybackEnded?.Invoke(this, EventArgs.Empty);
                PlaybackStateChanged?.Invoke(this, EventArgs.Empty);
            }
        });
        _player.EncounteredError += (_, _) => Dispatcher.BeginInvoke(() =>
            PlaybackFailed?.Invoke("LibVLC could not play this media file."));
    }

    public Guid? CurrentItemId { get; private set; }
    public RunSheetItemType? CurrentItemType { get; private set; }
    public bool IsBlack => _black;
    public bool IsPlaying => _player.IsPlaying;

    public TimeSpan Position => TimeSpan.FromMilliseconds(Math.Max(0, _player.Time));
    public TimeSpan? Duration => _player.Length > 0 ? TimeSpan.FromMilliseconds(_player.Length) : null;

    public void ShowItem(RunSheetItem item)
    {
        ResetSurfaces();
        CurrentItemId = item.Id;
        CurrentItemType = item.Type;
        _loop = item.Loop;
        _volume = Math.Clamp(item.Volume, 0, 1);

        if (string.IsNullOrWhiteSpace(item.SourcePath) || !File.Exists(item.SourcePath)) return;

        switch (item.Type)
        {
            case RunSheetItemType.Image:
                StopPlayer();
                ImageSurface.Source = LoadBitmap(item.SourcePath);
                ImageSurface.Stretch = item.ImageScale == ImageScaleMode.Fill ? Stretch.UniformToFill : Stretch.Uniform;
                ImageSurface.Visibility = Visibility.Visible;
                break;

            case RunSheetItemType.Video:
                VideoSurface.Visibility = Visibility.Visible;
                PlayMedia(item.SourcePath);
                break;

            case RunSheetItemType.Audio:
                VideoSurface.Visibility = Visibility.Collapsed;
                PlayMedia(item.SourcePath);
                break;
        }

        ApplyBlackState();
    }

    public void Play()
    {
        if (CurrentItemType is RunSheetItemType.Video or RunSheetItemType.Audio)
            _player.Play();
    }

    public void Pause()
    {
        if (CurrentItemType is RunSheetItemType.Video or RunSheetItemType.Audio)
            _player.SetPause(true);
    }

    public void TogglePlayPause()
    {
        if (CurrentItemType is not (RunSheetItemType.Video or RunSheetItemType.Audio)) return;
        if (_player.IsPlaying) _player.SetPause(true);
        else _player.Play();
    }

    public void StopPlayback()
    {
        if (CurrentItemType is RunSheetItemType.Video or RunSheetItemType.Audio)
        {
            try
            {
                _player.Stop();
                _player.Time = 0;
            }
            catch { }
        }
    }

    public void Seek(TimeSpan position)
    {
        if (!_player.IsSeekable) return;
        try { _player.Time = Math.Max(0, (long)position.TotalMilliseconds); } catch { }
    }

    public void SetVolume(double value)
    {
        _volume = Math.Clamp(value, 0, 1);
        ApplyAudioState();
    }

    public void SetMuted(bool muted)
    {
        _muted = muted;
        ApplyAudioState();
    }

    public void SetLoop(bool loop) => _loop = loop;

    public void SetBlack(bool black)
    {
        _black = black;
        ApplyBlackState();
    }

    public void ClearContent()
    {
        StopPlayer();
        ResetSurfaces();
        CurrentItemId = null;
        CurrentItemType = null;
        _black = true;
        ApplyBlackState();
    }

    private void PlayMedia(string path)
    {
        try
        {
            StopPlayer();
            using var media = new Media(MediaRuntime.LibVlc, new Uri(path, UriKind.Absolute));
            _player.Media = media;
            ApplyAudioState();
            if (!_player.Play()) PlaybackFailed?.Invoke("LibVLC could not start playback.");
        }
        catch (Exception ex)
        {
            PlaybackFailed?.Invoke(ex.Message);
        }
    }

    private void ApplyAudioState()
    {
        try
        {
            _player.Volume = (int)Math.Round(_volume * 100);
            _player.Mute = _muted;
        }
        catch { }
    }

    private void ApplyBlackState()
    {
        GlobalBlackOverlay.Visibility = _black ? Visibility.Visible : Visibility.Collapsed;
        VideoBlackOverlay.Visibility = _black ? Visibility.Visible : Visibility.Collapsed;
    }

    private void ResetSurfaces()
    {
        ImageSurface.Source = null;
        ImageSurface.Visibility = Visibility.Collapsed;
        VideoSurface.Visibility = Visibility.Collapsed;
        Root.Background = Brushes.Black;
    }

    private void StopPlayer()
    {
        try { _player.Stop(); } catch { }
        try { _player.Media = null; } catch { }
    }

    protected override void OnClosed(EventArgs e)
    {
        try { StopPlayer(); } catch { }
        VideoSurface.MediaPlayer = null;
        _player.Dispose();
        base.OnClosed(e);
    }

    private static BitmapImage LoadBitmap(string path)
    {
        var bmp = new BitmapImage();
        bmp.BeginInit();
        bmp.CacheOption = BitmapCacheOption.OnLoad;
        bmp.UriSource = new Uri(path, UriKind.Absolute);
        bmp.EndInit();
        bmp.Freeze();
        return bmp;
    }
}
