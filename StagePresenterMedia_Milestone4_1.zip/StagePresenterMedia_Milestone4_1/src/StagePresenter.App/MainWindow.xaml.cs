using LibVLCSharp.Shared;
using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using StagePresenter.Models;
using StagePresenter.Services;
using Forms = System.Windows.Forms;

namespace StagePresenter;

public partial class MainWindow : Window
{
    private static readonly HashSet<string> ImageExtensions = new(StringComparer.OrdinalIgnoreCase)
    { ".bmp", ".jpg", ".jpeg", ".png", ".gif", ".tif", ".tiff" };

    private static readonly HashSet<string> VideoExtensions = new(StringComparer.OrdinalIgnoreCase)
    { ".avi", ".mpeg", ".m1v", ".m2v", ".m4v", ".mov", ".mpg", ".mp4", ".wmv", ".3gp", ".3g2", ".mkv", ".webm", ".ts", ".m2ts", ".mts", ".flv" };

    private static readonly HashSet<string> AudioExtensions = new(StringComparer.OrdinalIgnoreCase)
    { ".mp2", ".mp3", ".m4a", ".wav", ".wma", ".aac", ".flac", ".ogg", ".opus" };

    private readonly ObservableCollection<RunSheetItem> _items = new();
    private readonly OutputController _output = new();
    private readonly MediaPlayer _previewPlayer;
    private readonly DispatcherTimer _positionTimer;
    private readonly DispatcherTimer _imageAdvanceTimer;
    private readonly DispatcherTimer _autoSaveTimer;
    private readonly DispatcherTimer _previewPrimeTimer;
    private readonly AppSettings _settings;

    private RunSheetDocument _document = NewDocument();
    private string? _currentDocumentPath;
    private bool _loadingSettings;
    private bool _updatingSeek;
    private bool _previewPriming;
    private bool _dirty;
    private Guid? _liveItemId;

    public MainWindow()
    {
        InitializeComponent();
        RunSheetList.ItemsSource = _items;
        ImageScaleCombo.SelectedIndex = 0;
        _settings = AppSettingsService.Load();

        _previewPlayer = new MediaPlayer(MediaRuntime.LibVlc) { Mute = true, Volume = 0 };
        PreviewVideo.MediaPlayer = _previewPlayer;
        _previewPlayer.EncounteredError += (_, _) => Dispatcher.BeginInvoke(() =>
        {
            PreviewVideo.Visibility = Visibility.Collapsed;
            PreviewPlaceholder.Visibility = Visibility.Visible;
            PreviewPlaceholder.Text = "Video preview unavailable";
        });
        _previewPlayer.Playing += (_, _) => Dispatcher.BeginInvoke(() =>
        {
            if (_previewPriming) _previewPrimeTimer.Start();
        });

        _output.PlaybackEnded += Output_PlaybackEnded;
        _output.PlaybackOpened += (_, _) => Dispatcher.BeginInvoke(UpdatePlaybackPosition);
        _output.PlaybackStateChanged += (_, _) => Dispatcher.BeginInvoke(UpdatePlaybackButtons);
        _output.PlaybackFailed += message => Dispatcher.BeginInvoke(() =>
            MessageBox.Show(this, message, "Projector playback failed", MessageBoxButton.OK, MessageBoxImage.Error));

        _positionTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(250) };
        _positionTimer.Tick += (_, _) => UpdatePlaybackPosition();
        _positionTimer.Start();

        _imageAdvanceTimer = new DispatcherTimer();
        _imageAdvanceTimer.Tick += (_, _) =>
        {
            _imageAdvanceTimer.Stop();
            AdvanceLiveItem(1);
        };

        _autoSaveTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(10) };
        _autoSaveTimer.Tick += (_, _) => AutoSaveIfNeeded();
        _autoSaveTimer.Start();

        _previewPrimeTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(250) };
        _previewPrimeTimer.Tick += (_, _) =>
        {
            _previewPrimeTimer.Stop();
            if (!_previewPriming) return;
            _previewPriming = false;
            try
            {
                _previewPlayer.Time = 0;
                _previewPlayer.SetPause(true);
            }
            catch { }
        };

        RefreshMonitors();
        UpdateTitleAndStatus();
        RefreshPreview();
        Loaded += (_, _) => RestoreRecoveryIfAvailable();
    }

    private static RunSheetDocument NewDocument() => new() { Name = "Untitled Run Sheet", FormatVersion = 4 };
    private RunSheetItem? Selected => RunSheetList.SelectedItem as RunSheetItem;
    private RunSheetItem? LiveItem => _liveItemId is Guid id ? _items.FirstOrDefault(x => x.Id == id) : null;

    private void RefreshMonitors()
    {
        var selectedDevice = (MonitorCombo.SelectedItem as MonitorInfo)?.DeviceName ?? _settings.LastMonitorDeviceName;
        var monitors = MonitorService.GetMonitors();
        MonitorCombo.ItemsSource = monitors;
        MonitorCombo.SelectedItem = monitors.FirstOrDefault(x => x.DeviceName == selectedDevice)
                                    ?? monitors.FirstOrDefault(x => !x.IsPrimary)
                                    ?? monitors.FirstOrDefault();
        UpdateStatus();
    }

    private void AddImage_Click(object sender, RoutedEventArgs e)
        => AddFromDialog("Images|*.bmp;*.jpg;*.jpeg;*.png;*.gif;*.tif;*.tiff|All files|*.*", RunSheetItemType.Image);

    private void AddVideo_Click(object sender, RoutedEventArgs e)
        => AddFromDialog("Video|*.mp4;*.mov;*.mkv;*.webm;*.avi;*.mpeg;*.mpg;*.m4v;*.wmv;*.ts;*.m2ts;*.mts;*.flv;*.3gp;*.3g2|All files|*.*", RunSheetItemType.Video);

    private void AddAudio_Click(object sender, RoutedEventArgs e)
        => AddFromDialog("Audio|*.mp3;*.wav;*.m4a;*.aac;*.flac;*.ogg;*.opus;*.wma;*.mp2|All files|*.*", RunSheetItemType.Audio);

    private void AddMixedMedia_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Multiselect = true,
            InitialDirectory = ExistingDirectory(_settings.LastMediaFolder),
            Filter = "Presentation media|*.bmp;*.jpg;*.jpeg;*.png;*.gif;*.tif;*.tiff;*.mp4;*.mov;*.mkv;*.webm;*.avi;*.mpeg;*.mpg;*.m4v;*.wmv;*.ts;*.m2ts;*.mts;*.flv;*.3gp;*.3g2;*.mp3;*.wav;*.m4a;*.aac;*.flac;*.ogg;*.opus;*.wma;*.mp2|All files|*.*"
        };
        if (dialog.ShowDialog() == true)
        {
            RememberMediaFolder(dialog.FileNames.FirstOrDefault());
            AddMediaPaths(dialog.FileNames);
        }
    }

    private void AddFromDialog(string filter, RunSheetItemType expectedType)
    {
        var dialog = new OpenFileDialog
        {
            Multiselect = true,
            Filter = filter,
            InitialDirectory = ExistingDirectory(_settings.LastMediaFolder)
        };
        if (dialog.ShowDialog() != true) return;
        RememberMediaFolder(dialog.FileNames.FirstOrDefault());

        var added = false;
        foreach (var path in dialog.FileNames)
        {
            var item = CreateItem(path);
            if (item is not null && item.Type == expectedType)
            {
                _items.Add(item);
                added = true;
            }
        }
        if (added)
        {
            MarkDirty();
            SelectLastItem();
        }
    }

    private void AddMediaPaths(IEnumerable<string> paths)
    {
        var added = false;
        foreach (var path in ExpandDroppedPaths(paths))
        {
            var item = CreateItem(path);
            if (item is null) continue;
            _items.Add(item);
            added = true;
        }
        if (added)
        {
            MarkDirty();
            SelectLastItem();
        }
    }

    private static IEnumerable<string> ExpandDroppedPaths(IEnumerable<string> paths)
    {
        foreach (var path in paths)
        {
            if (File.Exists(path))
            {
                yield return path;
                continue;
            }
            if (!Directory.Exists(path)) continue;
            IEnumerable<string> files;
            try { files = Directory.EnumerateFiles(path, "*", SearchOption.TopDirectoryOnly).OrderBy(x => x); }
            catch { continue; }
            foreach (var file in files) yield return file;
        }
    }

    private static RunSheetItem? CreateItem(string path)
    {
        if (!File.Exists(path)) return null;
        var ext = Path.GetExtension(path);
        var type = ImageExtensions.Contains(ext) ? RunSheetItemType.Image
            : VideoExtensions.Contains(ext) ? RunSheetItemType.Video
            : AudioExtensions.Contains(ext) ? RunSheetItemType.Audio
            : (RunSheetItemType?)null;
        if (type is null) return null;

        return new RunSheetItem
        {
            Type = type.Value,
            Title = Path.GetFileNameWithoutExtension(path),
            SourcePath = Path.GetFullPath(path),
            Volume = 1.0,
            ImageDurationSeconds = 5.0,
            ImageScale = ImageScaleMode.Fit
        };
    }

    private void SelectLastItem()
    {
        if (_items.Count == 0) return;
        RunSheetList.SelectedIndex = _items.Count - 1;
        RunSheetList.ScrollIntoView(RunSheetList.SelectedItem);
    }

    private void Window_Drop(object sender, DragEventArgs e)
    {
        if (e.Data.GetData(DataFormats.FileDrop) is string[] files) AddMediaPaths(files);
    }

    private void RunSheetList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        LoadSelectedSettings();
        RefreshPreview();
    }

    private void StopPreview()
    {
        _previewPriming = false;
        _previewPrimeTimer.Stop();
        try { _previewPlayer.Stop(); } catch { }
        try { _previewPlayer.Media = null; } catch { }
        PreviewVideo.Visibility = Visibility.Collapsed;
    }

    private void RefreshPreview()
    {
        PreviewImage.Source = null;
        PreviewImage.Visibility = Visibility.Collapsed;
        StopPreview();
        PreviewPlaceholder.Visibility = Visibility.Visible;

        var item = Selected;
        if (item is null)
        {
            PreviewPlaceholder.Text = "No media selected";
            SelectedInfoText.Text = "Select an item";
            return;
        }

        SelectedInfoText.Text = $"{item.TypeLabel}  •  {item.FileName}";
        if (!item.FileExists)
        {
            PreviewPlaceholder.Text = "Media file is missing — use Relink";
            return;
        }

        switch (item.Type)
        {
            case RunSheetItemType.Image:
                try
                {
                    PreviewImage.Source = LoadBitmap(item.SourcePath!);
                    PreviewImage.Stretch = item.ImageScale == ImageScaleMode.Fill ? Stretch.UniformToFill : Stretch.Uniform;
                    PreviewImage.Visibility = Visibility.Visible;
                    PreviewPlaceholder.Visibility = Visibility.Collapsed;
                }
                catch { PreviewPlaceholder.Text = "Image could not be loaded"; }
                break;

            case RunSheetItemType.Video:
                try
                {
                    using var media = new Media(MediaRuntime.LibVlc, new Uri(item.SourcePath!, UriKind.Absolute));
                    _previewPlayer.Media = media;
                    _previewPlayer.Mute = true;
                    _previewPlayer.Volume = 0;
                    PreviewVideo.Visibility = Visibility.Visible;
                    PreviewPlaceholder.Visibility = Visibility.Collapsed;
                    _previewPriming = true;
                    _previewPlayer.Play();
                }
                catch { PreviewPlaceholder.Text = "Video preview unavailable"; }
                break;

            case RunSheetItemType.Audio:
                PreviewPlaceholder.Text = $"Audio ready: {item.FileName}";
                break;
        }
    }

    private void LoadSelectedSettings()
    {
        _loadingSettings = true;
        try
        {
            var item = Selected;
            if (item is null)
            {
                LoopCheck.IsChecked = false;
                AutoAdvanceCheck.IsChecked = false;
                VolumeSlider.Value = 1;
                ImageDurationBox.Text = "5";
                ImageScaleCombo.SelectedIndex = 0;
                ImageDurationBox.IsEnabled = false;
                ImageScaleCombo.IsEnabled = false;
                LoopCheck.IsEnabled = false;
                return;
            }

            LoopCheck.IsChecked = item.Loop;
            AutoAdvanceCheck.IsChecked = item.AutoAdvance;
            VolumeSlider.Value = Math.Clamp(item.Volume, 0, 1);
            ImageDurationBox.Text = item.ImageDurationSeconds.ToString("0.##");
            ImageScaleCombo.SelectedIndex = item.ImageScale == ImageScaleMode.Fill ? 1 : 0;

            var isImage = item.Type == RunSheetItemType.Image;
            ImageDurationBox.IsEnabled = isImage;
            ImageScaleCombo.IsEnabled = isImage;
            LoopCheck.IsEnabled = item.Type is RunSheetItemType.Video or RunSheetItemType.Audio;
        }
        finally { _loadingSettings = false; }
    }

    private void ItemSettings_Changed(object sender, RoutedEventArgs e) => SaveSelectedSettings(refreshPreview: false);
    private void ImageScaleCombo_SelectionChanged(object sender, SelectionChangedEventArgs e) => SaveSelectedSettings(refreshPreview: true);

    private void SaveSelectedSettings(bool refreshPreview)
    {
        if (_loadingSettings || Selected is not { } item) return;
        item.Loop = LoopCheck.IsChecked == true;
        item.AutoAdvance = AutoAdvanceCheck.IsChecked == true;
        item.Volume = VolumeSlider.Value;
        item.ImageScale = ImageScaleCombo.SelectedIndex == 1 ? ImageScaleMode.Fill : ImageScaleMode.Fit;
        if (double.TryParse(ImageDurationBox.Text, out var seconds))
            item.ImageDurationSeconds = Math.Clamp(seconds, 0.5, 3600);

        if (_liveItemId == item.Id)
        {
            _output.SetLoop(item.Loop);
            _output.SetVolume(item.Volume);
        }
        MarkDirty();
        if (refreshPreview) RefreshPreview();
    }

    private void ImageDurationBox_LostFocus(object sender, RoutedEventArgs e)
    {
        SaveSelectedSettings(refreshPreview: false);
        if (Selected is { } item) ImageDurationBox.Text = item.ImageDurationSeconds.ToString("0.##");
    }

    private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_loadingSettings) return;
        if (Selected is { } item)
        {
            item.Volume = e.NewValue;
            if (_liveItemId == item.Id) _output.SetVolume(e.NewValue);
            MarkDirty();
        }
    }

    private void MuteCheck_Changed(object sender, RoutedEventArgs e) => _output.SetMuted(MuteCheck.IsChecked == true);

    private void TakeLive_Click(object sender, RoutedEventArgs e) => TakeSelectedLive();
    private void RunSheetList_MouseDoubleClick(object sender, MouseButtonEventArgs e) => TakeSelectedLive();

    private void TakeSelectedLive()
    {
        if (Selected is not { } item) return;
        if (!item.FileExists)
        {
            MessageBox.Show(this, "The selected media file cannot be found. Relink it before going live.", "Missing media", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (!_output.IsOpen)
        {
            MessageBox.Show(this, "Open a projector/display output first.", "Projector not open", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        _imageAdvanceTimer.Stop();
        _liveItemId = item.Id;
        _output.Show(item);
        _output.SetMuted(MuteCheck.IsChecked == true);
        _output.SetBlack(false);
        BlackButton.Content = "BLACK";
        LiveStatusText.Text = $"LIVE: {item.Title}";

        if (item.Type == RunSheetItemType.Image && item.AutoAdvance) StartImageAdvanceTimer(item);
        UpdatePlaybackButtons();
    }

    private void StartImageAdvanceTimer(RunSheetItem item)
    {
        _imageAdvanceTimer.Stop();
        _imageAdvanceTimer.Interval = TimeSpan.FromSeconds(Math.Max(.5, item.ImageDurationSeconds));
        _imageAdvanceTimer.Start();
    }

    private void PlayPause_Click(object sender, RoutedEventArgs e) => _output.TogglePlayPause();
    private void Play_Click(object sender, RoutedEventArgs e) => _output.Play();
    private void Stop_Click(object sender, RoutedEventArgs e) => _output.Stop();

    private void UpdatePlaybackButtons()
    {
        PlayPauseButton.Content = _output.IsPlaying ? "Ⅱ Pause" : "▶ Play / Pause";
    }

    private void SeekSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_updatingSeek || _output.Duration is not TimeSpan duration || duration.TotalSeconds <= 0) return;
        if (Math.Abs(_output.Position.TotalSeconds - e.NewValue) > .5)
            _output.Seek(TimeSpan.FromSeconds(e.NewValue));
    }

    private void UpdatePlaybackPosition()
    {
        var duration = _output.Duration;
        var position = _output.Position;
        _updatingSeek = true;
        try
        {
            SeekSlider.Maximum = duration?.TotalSeconds is > 0 ? duration.Value.TotalSeconds : 1;
            SeekSlider.Value = Math.Clamp(position.TotalSeconds, 0, SeekSlider.Maximum);
            TimeText.Text = $"{FormatTime(position)} / {FormatTime(duration ?? TimeSpan.Zero)}";
        }
        finally { _updatingSeek = false; }
        UpdatePlaybackButtons();
    }

    private static string FormatTime(TimeSpan value)
        => value.TotalHours >= 1 ? value.ToString(@"h\:mm\:ss") : value.ToString(@"mm\:ss");

    private void Output_PlaybackEnded(object? sender, EventArgs e)
    {
        Dispatcher.BeginInvoke(() =>
        {
            if (LiveItem?.AutoAdvance == true) AdvanceLiveItem(1);
        });
    }

    private void PreviousItem_Click(object sender, RoutedEventArgs e) => AdvanceLiveItem(-1);
    private void NextItem_Click(object sender, RoutedEventArgs e) => AdvanceLiveItem(1);

    private void AdvanceLiveItem(int delta)
    {
        if (_items.Count == 0) return;
        var currentIndex = LiveItem is { } live ? _items.IndexOf(live) : RunSheetList.SelectedIndex;
        if (currentIndex < 0) currentIndex = 0;
        var next = currentIndex + delta;
        if (next < 0 || next >= _items.Count) return;
        RunSheetList.SelectedIndex = next;
        RunSheetList.ScrollIntoView(RunSheetList.SelectedItem);
        TakeSelectedLive();
    }

    private void OpenOutput_Click(object sender, RoutedEventArgs e)
    {
        if (MonitorCombo.SelectedItem is not MonitorInfo monitor) return;
        if (monitor.IsPrimary && MonitorService.GetMonitors().Count > 1)
        {
            var result = MessageBox.Show(this,
                "The selected display is the primary/operator screen. Open the projector output there anyway?",
                "Primary display selected", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result != MessageBoxResult.Yes) return;
        }

        _output.OpenOutput(monitor);
        _output.SetBlack(true);
        _liveItemId = null;
        BlackButton.Content = "UNBLACK";
        LiveStatusText.Text = $"PROJECTOR READY · BLACK · {monitor.DeviceName}";
        _settings.LastMonitorDeviceName = monitor.DeviceName;
        AppSettingsService.Save(_settings);
        UpdateStatus();
    }

    private void CloseOutput_Click(object sender, RoutedEventArgs e)
    {
        _imageAdvanceTimer.Stop();
        _output.CloseOutput();
        _liveItemId = null;
        BlackButton.Content = "BLACK";
        LiveStatusText.Text = "PROJECTOR CLOSED";
        UpdatePlaybackPosition();
        UpdateStatus();
    }

    private void RefreshDisplays_Click(object sender, RoutedEventArgs e) => RefreshMonitors();

    private void Black_Click(object sender, RoutedEventArgs e)
    {
        if (!_output.IsOpen) return;
        var newBlack = !_output.IsBlack;
        _output.SetBlack(newBlack);
        BlackButton.Content = newBlack ? "UNBLACK" : "BLACK";

        if (newBlack)
        {
            _imageAdvanceTimer.Stop();
            LiveStatusText.Text = LiveItem is { } live ? $"BLACK · {live.Title} continues" : "PROJECTOR BLACK";
        }
        else
        {
            if (LiveItem is { } live)
            {
                LiveStatusText.Text = $"LIVE: {live.Title}";
                if (live.Type == RunSheetItemType.Image && live.AutoAdvance) StartImageAdvanceTimer(live);
            }
            else LiveStatusText.Text = "PROJECTOR READY";
        }
    }

    private void MoveUp_Click(object sender, RoutedEventArgs e)
    {
        if (Selected is not { } item) return;
        var index = _items.IndexOf(item);
        if (index <= 0) return;
        _items.Move(index, index - 1);
        RunSheetList.SelectedItem = item;
        MarkDirty();
    }

    private void MoveDown_Click(object sender, RoutedEventArgs e)
    {
        if (Selected is not { } item) return;
        var index = _items.IndexOf(item);
        if (index < 0 || index >= _items.Count - 1) return;
        _items.Move(index, index + 1);
        RunSheetList.SelectedItem = item;
        MarkDirty();
    }

    private void Remove_Click(object sender, RoutedEventArgs e)
    {
        if (Selected is not { } item) return;
        if (_liveItemId == item.Id)
        {
            _output.SetBlack(true);
            _output.Stop();
            _liveItemId = null;
            BlackButton.Content = "UNBLACK";
            LiveStatusText.Text = "PROJECTOR BLACK";
        }
        _items.Remove(item);
        MarkDirty();
        RefreshPreview();
    }

    private void RelinkSelected_Click(object sender, RoutedEventArgs e)
    {
        if (Selected is not { } item) return;
        var dialog = new OpenFileDialog
        {
            Filter = FilterForType(item.Type),
            InitialDirectory = ExistingDirectory(Path.GetDirectoryName(item.SourcePath)) ?? ExistingDirectory(_settings.LastMediaFolder)
        };
        if (dialog.ShowDialog() != true) return;
        var replacement = CreateItem(dialog.FileName);
        if (replacement is null || replacement.Type != item.Type)
        {
            MessageBox.Show(this, "Choose a media file of the same type as the selected run-sheet item.", "Wrong media type", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        item.SourcePath = replacement.SourcePath;
        RememberMediaFolder(dialog.FileName);
        RunSheetList.Items.Refresh();
        MarkDirty();
        RefreshPreview();
    }

    private void RelinkMissing_Click(object sender, RoutedEventArgs e)
    {
        var missing = _items.Where(x => !x.FileExists).ToList();
        if (missing.Count == 0)
        {
            MessageBox.Show(this, "No missing media files were found.", "Relink media", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        using var dialog = new Forms.FolderBrowserDialog { Description = "Choose a folder that contains the missing media" };
        if (dialog.ShowDialog() != Forms.DialogResult.OK) return;

        List<string> files;
        try { files = Directory.EnumerateFiles(dialog.SelectedPath, "*", SearchOption.AllDirectories).ToList(); }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Could not scan folder", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        var byName = files.GroupBy(x => Path.GetFileName(x), StringComparer.OrdinalIgnoreCase)
                          .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
        var fixedCount = 0;
        foreach (var item in missing)
        {
            if (string.IsNullOrWhiteSpace(item.SourcePath)) continue;
            var fileName = Path.GetFileName(item.SourcePath);
            if (!byName.TryGetValue(fileName, out var match)) continue;
            var candidate = CreateItem(match);
            if (candidate?.Type != item.Type) continue;
            item.SourcePath = Path.GetFullPath(match);
            fixedCount++;
        }

        if (fixedCount > 0)
        {
            MarkDirty();
            RunSheetList.Items.Refresh();
            RefreshPreview();
        }
        MessageBox.Show(this, $"Relinked {fixedCount} of {missing.Count} missing media item(s).", "Relink complete", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void CheckMissing_Click(object sender, RoutedEventArgs e)
    {
        var missing = _items.Where(x => !x.FileExists).ToList();
        if (missing.Count == 0)
        {
            MessageBox.Show(this, "All media files are available.", "Run-sheet check", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var lines = missing.Take(15).Select(x => $"• {x.Title} — {x.SourcePath}");
        var extra = missing.Count > 15 ? $"\n…and {missing.Count - 15} more." : string.Empty;
        MessageBox.Show(this, $"Missing media ({missing.Count}):\n\n{string.Join("\n", lines)}{extra}", "Run-sheet check", MessageBoxButton.OK, MessageBoxImage.Warning);
    }

    private void NewEvent_Click(object sender, RoutedEventArgs e)
    {
        if (!PromptSaveIfDirty()) return;
        _imageAdvanceTimer.Stop();
        if (_output.IsOpen) _output.SetBlack(true);
        _liveItemId = null;
        _items.Clear();
        _document = NewDocument();
        _currentDocumentPath = null;
        _dirty = false;
        AutoSaveService.Clear();
        LiveStatusText.Text = _output.IsOpen ? "PROJECTOR BLACK" : "PROJECTOR CLOSED";
        UpdateTitleAndStatus();
        RefreshPreview();
    }

    private void OpenEvent_Click(object sender, RoutedEventArgs e)
    {
        if (!PromptSaveIfDirty()) return;
        var dialog = new OpenFileDialog
        {
            Filter = "StagePresenter run sheet (*.sprevent)|*.sprevent|JSON (*.json)|*.json",
            InitialDirectory = ExistingDirectory(_settings.LastRunSheetFolder)
        };
        if (dialog.ShowDialog() != true) return;
        try
        {
            LoadDocument(RunSheetService.Load(dialog.FileName), dialog.FileName, dirty: false);
            _settings.LastRunSheetFolder = Path.GetDirectoryName(dialog.FileName);
            AppSettingsService.Save(_settings);
            AutoSaveService.Clear();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Open run sheet failed", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void SaveEvent_Click(object sender, RoutedEventArgs e) => SaveCurrent();
    private void SaveAsEvent_Click(object sender, RoutedEventArgs e) => SaveAs();

    private bool SaveCurrent()
    {
        if (string.IsNullOrWhiteSpace(_currentDocumentPath)) return SaveAs();
        return SaveTo(_currentDocumentPath);
    }

    private bool SaveAs()
    {
        var dialog = new SaveFileDialog
        {
            Filter = "StagePresenter run sheet (*.sprevent)|*.sprevent",
            FileName = MakeSafeFileName(_document.Name) + ".sprevent",
            InitialDirectory = ExistingDirectory(_settings.LastRunSheetFolder)
        };
        if (dialog.ShowDialog() != true) return false;
        _currentDocumentPath = dialog.FileName;
        _settings.LastRunSheetFolder = Path.GetDirectoryName(dialog.FileName);
        AppSettingsService.Save(_settings);
        return SaveTo(dialog.FileName);
    }

    private bool SaveTo(string path)
    {
        try
        {
            SyncDocumentFromUi();
            _document.Name = Path.GetFileNameWithoutExtension(path);
            RunSheetService.Save(path, _document);
            _dirty = false;
            AutoSaveService.Clear();
            UpdateTitleAndStatus();
            return true;
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Save failed", MessageBoxButton.OK, MessageBoxImage.Error);
            return false;
        }
    }

    private void PackageRunSheet_Click(object sender, RoutedEventArgs e)
    {
        if (_items.Count == 0)
        {
            MessageBox.Show(this, "Add media to the run sheet before packaging it.", "Nothing to package", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        var missing = _items.Count(x => !x.FileExists);
        if (missing > 0)
        {
            MessageBox.Show(this, $"Relink the {missing} missing media item(s) before creating a portable package.", "Missing media", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        using var dialog = new Forms.FolderBrowserDialog { Description = "Choose the folder where the portable run sheet will be created" };
        if (dialog.ShowDialog() != Forms.DialogResult.OK) return;
        try
        {
            SyncDocumentFromUi();
            var packageName = MakeSafeFileName(_document.Name);
            var packageFolder = Path.Combine(dialog.SelectedPath, packageName + "_Portable");
            var runSheetPath = RunSheetService.CreatePortablePackage(packageFolder, packageName, _document);
            MessageBox.Show(this, $"Portable package created.\n\n{runSheetPath}\n\nCopy the entire package folder to the presentation PC.",
                "Package complete", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Package failed", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void LoadDocument(RunSheetDocument loaded, string? path, bool dirty)
    {
        _imageAdvanceTimer.Stop();
        if (_output.IsOpen) _output.SetBlack(true);
        _liveItemId = null;
        _document = loaded;
        _currentDocumentPath = path;
        _items.Clear();
        foreach (var item in loaded.Items.Where(x => x.Type is RunSheetItemType.Image or RunSheetItemType.Video or RunSheetItemType.Audio))
            _items.Add(item);
        _dirty = dirty;
        if (_items.Count > 0) RunSheetList.SelectedIndex = 0;
        else RefreshPreview();
        UpdateTitleAndStatus();
    }

    private void SyncDocumentFromUi()
    {
        _document.FormatVersion = 4;
        _document.Items = _items.Select(x => x.Clone()).ToList();
    }

    private void MarkDirty()
    {
        _dirty = true;
        UpdateTitleAndStatus();
    }

    private void AutoSaveIfNeeded()
    {
        if (!_dirty || _items.Count == 0) return;
        try
        {
            SyncDocumentFromUi();
            AutoSaveService.Save(_document);
        }
        catch { }
    }

    private void RestoreRecoveryIfAvailable()
    {
        if (!AutoSaveService.Exists) return;
        try
        {
            var result = MessageBox.Show(this,
                "StagePresenter found an autosaved run sheet from an earlier session. Restore it?",
                "Recover run sheet", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                var recovered = AutoSaveService.Load();
                recovered.Name = "Recovered Run Sheet";
                LoadDocument(recovered, null, dirty: true);
            }
            else AutoSaveService.Clear();
        }
        catch { AutoSaveService.Clear(); }
    }

    private bool PromptSaveIfDirty()
    {
        if (!_dirty) return true;
        var result = MessageBox.Show(this, "Save changes to the current run sheet?", "Unsaved changes",
            MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
        return result switch
        {
            MessageBoxResult.Yes => SaveCurrent(),
            MessageBoxResult.No => true,
            _ => false
        };
    }

    private void UpdateTitleAndStatus()
    {
        EventTitle.Text = _document.Name + (_dirty ? " *" : string.Empty);
        CurrentFileText.Text = string.IsNullOrWhiteSpace(_currentDocumentPath) ? "Not saved" : _currentDocumentPath;
        UpdateStatus();
    }

    private void UpdateStatus()
    {
        var missing = _items.Count(x => !x.FileExists);
        var displays = MonitorService.GetMonitors().Count;
        StatusText.Text = $"{_items.Count} item(s) · {missing} missing · {displays} display(s)";
    }

    private void RememberMediaFolder(string? filePath)
    {
        if (string.IsNullOrWhiteSpace(filePath)) return;
        _settings.LastMediaFolder = Path.GetDirectoryName(filePath);
        AppSettingsService.Save(_settings);
    }

    private static string? ExistingDirectory(string? path) => !string.IsNullOrWhiteSpace(path) && Directory.Exists(path) ? path : null;

    private static string FilterForType(RunSheetItemType type) => type switch
    {
        RunSheetItemType.Image => "Images|*.bmp;*.jpg;*.jpeg;*.png;*.gif;*.tif;*.tiff|All files|*.*",
        RunSheetItemType.Video => "Video|*.mp4;*.mov;*.mkv;*.webm;*.avi;*.mpeg;*.mpg;*.m4v;*.wmv;*.ts;*.m2ts;*.mts;*.flv;*.3gp;*.3g2|All files|*.*",
        RunSheetItemType.Audio => "Audio|*.mp3;*.wav;*.m4a;*.aac;*.flac;*.ogg;*.opus;*.wma;*.mp2|All files|*.*",
        _ => "All files|*.*"
    };

    private static string MakeSafeFileName(string value)
    {
        foreach (var c in Path.GetInvalidFileNameChars()) value = value.Replace(c, '_');
        return string.IsNullOrWhiteSpace(value) ? "run-sheet" : value;
    }

    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (Keyboard.FocusedElement is TextBoxBase || (Keyboard.FocusedElement is ComboBox combo && combo.IsDropDownOpen)) return;

        if ((Keyboard.Modifiers & ModifierKeys.Control) != 0)
        {
            if (e.Key == Key.S)
            {
                if ((Keyboard.Modifiers & ModifierKeys.Shift) != 0) SaveAs(); else SaveCurrent();
                e.Handled = true;
                return;
            }
            if (e.Key == Key.N) { NewEvent_Click(sender, e); e.Handled = true; return; }
            if (e.Key == Key.O) { OpenEvent_Click(sender, e); e.Handled = true; return; }
        }

        if (e.Key == Key.Enter) { TakeSelectedLive(); e.Handled = true; }
        else if (e.Key == Key.B) { Black_Click(sender, e); e.Handled = true; }
        else if (e.Key == Key.Space) { _output.TogglePlayPause(); e.Handled = true; }
        else if (e.Key == Key.PageDown) { AdvanceLiveItem(1); e.Handled = true; }
        else if (e.Key == Key.PageUp) { AdvanceLiveItem(-1); e.Handled = true; }
        else if (e.Key == Key.Delete) { Remove_Click(sender, e); e.Handled = true; }
    }

    private static BitmapImage LoadBitmap(string path)
    {
        var bmp = new BitmapImage();
        bmp.BeginInit();
        bmp.CacheOption = BitmapCacheOption.OnLoad;
        bmp.UriSource = new Uri(path, UriKind.Absolute);
        bmp.EndInit();
        bmp.Freeze();
        return bmp;
    }

    private void Exit_Click(object sender, RoutedEventArgs e) => Close();

    private void Window_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        if (!PromptSaveIfDirty())
        {
            e.Cancel = true;
            return;
        }

        _positionTimer.Stop();
        _imageAdvanceTimer.Stop();
        _autoSaveTimer.Stop();
        _previewPrimeTimer.Stop();
        AutoSaveService.Clear();
        _output.CloseAll();
        StopPreview();
        PreviewVideo.MediaPlayer = null;
        _previewPlayer.Dispose();
    }
}
