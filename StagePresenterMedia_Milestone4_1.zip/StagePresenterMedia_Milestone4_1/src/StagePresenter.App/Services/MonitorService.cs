using System.Windows;
using Forms = System.Windows.Forms;

namespace StagePresenter.Services;

public sealed record MonitorInfo(int Index, string DeviceName, bool IsPrimary, Rect Bounds)
{
    public override string ToString() =>
        $"{Index + 1}: {DeviceName}  {(int)Bounds.Width}×{(int)Bounds.Height}{(IsPrimary ? " (Primary)" : "")}";
}

public static class MonitorService
{
    public static IReadOnlyList<MonitorInfo> GetMonitors() => Forms.Screen.AllScreens
        .Select((s, i) => new MonitorInfo(i, s.DeviceName, s.Primary,
            new Rect(s.Bounds.X, s.Bounds.Y, s.Bounds.Width, s.Bounds.Height)))
        .ToList();
}
