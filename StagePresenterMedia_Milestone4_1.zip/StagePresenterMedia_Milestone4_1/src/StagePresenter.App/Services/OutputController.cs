using StagePresenter.Models;
using StagePresenter.Views;
using System.Runtime.InteropServices;
using System.Windows.Interop;

namespace StagePresenter.Services;

public sealed class OutputController
{
    private const uint SwpNoActivate = 0x0010;
    private const uint SwpShowWindow = 0x0040;

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter,
        int X, int Y, int cx, int cy, uint uFlags);

    private OutputWindow? _window;
    private int? _monitorIndex;

    public event EventHandler? PlaybackEnded;
    public event EventHandler? PlaybackOpened;
    public event EventHandler? PlaybackStateChanged;
    public event Action<string>? PlaybackFailed;

    public bool IsOpen => _window is not null;
    public bool IsBlack => _window?.IsBlack ?? true;
    public bool IsPlaying => _window?.IsPlaying ?? false;
    public int? MonitorIndex => _monitorIndex;
    public Guid? CurrentItemId => _window?.CurrentItemId;
    public TimeSpan Position => _window?.Position ?? TimeSpan.Zero;
    public TimeSpan? Duration => _window?.Duration;

    public void OpenOutput(MonitorInfo monitor)
    {
        CloseOutput();

        var window = new OutputWindow
        {
            Left = monitor.Bounds.Left,
            Top = monitor.Bounds.Top,
            Width = monitor.Bounds.Width,
            Height = monitor.Bounds.Height
        };
        window.PlaybackEnded += (_, _) => PlaybackEnded?.Invoke(this, EventArgs.Empty);
        window.PlaybackOpened += (_, _) => PlaybackOpened?.Invoke(this, EventArgs.Empty);
        window.PlaybackStateChanged += (_, _) => PlaybackStateChanged?.Invoke(this, EventArgs.Empty);
        window.PlaybackFailed += message => PlaybackFailed?.Invoke(message);
        window.Show();

        window.WindowState = System.Windows.WindowState.Normal;
        var handle = new WindowInteropHelper(window).Handle;
        SetWindowPos(handle, IntPtr.Zero,
            (int)monitor.Bounds.Left, (int)monitor.Bounds.Top,
            (int)monitor.Bounds.Width, (int)monitor.Bounds.Height,
            SwpNoActivate | SwpShowWindow);

        _window = window;
        _monitorIndex = monitor.Index;
        _window.SetBlack(true);
    }

    public void CloseOutput()
    {
        if (_window is null) return;
        try { _window.Close(); } catch { }
        _window = null;
        _monitorIndex = null;
    }

    public void Show(RunSheetItem item) => _window?.ShowItem(item);
    public void Play() => _window?.Play();
    public void Pause() => _window?.Pause();
    public void TogglePlayPause() => _window?.TogglePlayPause();
    public void Stop() => _window?.StopPlayback();
    public void Seek(TimeSpan position) => _window?.Seek(position);
    public void SetVolume(double value) => _window?.SetVolume(value);
    public void SetMuted(bool muted) => _window?.SetMuted(muted);
    public void SetLoop(bool loop) => _window?.SetLoop(loop);
    public void SetBlack(bool black) => _window?.SetBlack(black);
    public void Clear() => _window?.ClearContent();
    public void CloseAll() => CloseOutput();
}
