using StagePresenter.Models;

namespace StagePresenter.Services;

public static class AutoSaveService
{
    private static readonly string Folder = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "StagePresenter");
    public static string AutoSavePath => Path.Combine(Folder, "recovery.sprevent");

    public static bool Exists => File.Exists(AutoSavePath);

    public static void Save(RunSheetDocument document)
    {
        Directory.CreateDirectory(Folder);
        RunSheetService.Save(AutoSavePath, document);
    }

    public static RunSheetDocument Load() => RunSheetService.Load(AutoSavePath);

    public static void Clear()
    {
        try { if (File.Exists(AutoSavePath)) File.Delete(AutoSavePath); } catch { }
    }
}
