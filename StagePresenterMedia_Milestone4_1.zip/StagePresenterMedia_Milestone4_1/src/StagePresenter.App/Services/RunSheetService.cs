using System.Text.Json;
using StagePresenter.Models;

namespace StagePresenter.Services;

public static class RunSheetService
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    public static void Save(string path, RunSheetDocument document)
    {
        var fullPath = Path.GetFullPath(path);
        var baseDirectory = Path.GetDirectoryName(fullPath) ?? Environment.CurrentDirectory;
        Directory.CreateDirectory(baseDirectory);

        var copy = document.Clone();
        copy.FormatVersion = 4;
        copy.ModifiedUtc = DateTime.UtcNow;
        foreach (var item in copy.Items)
            item.SourcePath = ToPortablePath(baseDirectory, item.SourcePath);

        File.WriteAllText(fullPath, JsonSerializer.Serialize(copy, JsonOptions));
        document.ModifiedUtc = copy.ModifiedUtc;
    }

    public static RunSheetDocument Load(string path)
    {
        var fullPath = Path.GetFullPath(path);
        var json = File.ReadAllText(fullPath);
        var document = JsonSerializer.Deserialize<RunSheetDocument>(json, JsonOptions)
                       ?? throw new InvalidDataException("The run-sheet file is empty or invalid.");

        var baseDirectory = Path.GetDirectoryName(fullPath) ?? Environment.CurrentDirectory;
        foreach (var item in document.Items)
        {
            if (string.IsNullOrWhiteSpace(item.SourcePath)) continue;
            if (!Path.IsPathRooted(item.SourcePath))
                item.SourcePath = Path.GetFullPath(Path.Combine(baseDirectory, item.SourcePath));
        }
        return document;
    }

    public static string CreatePortablePackage(string destinationFolder, string packageName, RunSheetDocument document)
    {
        Directory.CreateDirectory(destinationFolder);
        var mediaFolder = Path.Combine(destinationFolder, "Media");
        Directory.CreateDirectory(mediaFolder);

        var packaged = document.Clone();
        packaged.Name = packageName;
        packaged.FormatVersion = 4;

        for (var i = 0; i < packaged.Items.Count; i++)
        {
            var item = packaged.Items[i];
            if (string.IsNullOrWhiteSpace(item.SourcePath) || !File.Exists(item.SourcePath)) continue;
            var safeName = SanitizeFileName(Path.GetFileName(item.SourcePath));
            var targetName = $"{i + 1:000}_{safeName}";
            var targetPath = UniquePath(mediaFolder, targetName);
            File.Copy(item.SourcePath, targetPath, overwrite: false);
            item.SourcePath = targetPath;
        }

        var runSheetPath = Path.Combine(destinationFolder, $"{SanitizeFileName(packageName)}.sprevent");
        Save(runSheetPath, packaged);
        return runSheetPath;
    }

    private static string? ToPortablePath(string baseDirectory, string? sourcePath)
    {
        if (string.IsNullOrWhiteSpace(sourcePath)) return sourcePath;
        try
        {
            var fullSource = Path.GetFullPath(sourcePath);
            var relative = Path.GetRelativePath(baseDirectory, fullSource);
            if (!relative.StartsWith(".." + Path.DirectorySeparatorChar, StringComparison.Ordinal) && relative != ".." && !Path.IsPathRooted(relative))
                return relative;
            return fullSource;
        }
        catch { return sourcePath; }
    }

    private static string SanitizeFileName(string value)
    {
        foreach (var c in Path.GetInvalidFileNameChars()) value = value.Replace(c, '_');
        return string.IsNullOrWhiteSpace(value) ? "run-sheet" : value;
    }

    private static string UniquePath(string folder, string fileName)
    {
        var candidate = Path.Combine(folder, fileName);
        if (!File.Exists(candidate)) return candidate;
        var stem = Path.GetFileNameWithoutExtension(fileName);
        var ext = Path.GetExtension(fileName);
        var n = 2;
        do candidate = Path.Combine(folder, $"{stem}_{n++}{ext}"); while (File.Exists(candidate));
        return candidate;
    }
}
