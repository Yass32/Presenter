using LibVLCSharp.Shared;

namespace StagePresenter.Services;

public static class MediaRuntime
{
    private static LibVLC? _libVlc;

    public static LibVLC LibVlc => _libVlc ?? throw new InvalidOperationException("Media runtime is not initialized.");

    public static void Initialize()
    {
        if (_libVlc is not null) return;
        Core.Initialize();
        _libVlc = new LibVLC("--no-video-title-show", "--quiet");
    }

    public static void Dispose()
    {
        _libVlc?.Dispose();
        _libVlc = null;
    }
}
